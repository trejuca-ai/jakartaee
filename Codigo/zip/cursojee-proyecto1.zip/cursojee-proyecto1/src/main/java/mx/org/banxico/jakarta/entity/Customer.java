package mx.org.banxico.jakarta.entity;

public class Customer {

}
